
================================================================================
Status Summary
================================================================================

This is a development version of LDAP profile add on module to the LDAP package.

This module allows a mapping between ldap fields and drupal fields with the help
of a UI.

If you need to add an expression to translate the ldap value into a different 
format for drupal, this can be done through the ldap_profile_data_translate.inc
file.

Eventually this conversion process will be included in the UI so no files have to
be modified.
